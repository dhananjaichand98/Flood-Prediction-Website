#!/usr/bin/env python
import imp
import os
from public import public
import python_files


@public
def source(name, path):
    return imp.load_source(name, path)


def _sources(name, path):
    find = list(python_files.find(path))
    for f in find:
        relpath = f.replace("%s/" % os.path.dirname(path), "")
        pyname = relpath.replace("__init__.py", "")[:-3].replace("/", ".")
        _name = pyname
        if name:
            _name = "%s.%s" % (name, pyname)
        module = source(_name, f)
        yield module


@public
def sources(name, path):
    return list(_sources(name, path))
