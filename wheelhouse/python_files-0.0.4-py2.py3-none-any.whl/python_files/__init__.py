#!/usr/bin/env python
import os
from public import public


def _pyfiles(files):
    for f in files:
        if os.path.splitext(f)[1] == ".py":
            yield f


@public
def find(path):
    for path, dirs, files in os.walk(path):
        for f in _pyfiles(files):
            yield os.path.join(path, f)
